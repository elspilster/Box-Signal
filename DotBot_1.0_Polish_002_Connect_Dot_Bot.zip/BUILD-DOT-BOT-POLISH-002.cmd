@echo off
setlocal
cd /d "%~dp0"
echo.
echo ================================================
echo   DOT BOT - INSTALLER POLISH 001 (32-BIT TEST)
echo ================================================
echo.
echo Packaging-only test: official Dot Bot icon and Box Signal branding.
echo Dot Bot's application code is unchanged from diagnostic build 003D.
echo.
echo Cleaning packaging dependencies from this build folder only...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /q package-lock.json
if exist dist rmdir /s /q dist

echo Installing Dot Bot packaging dependencies...
set npm_config_arch=ia32
set npm_config_platform=win32
call npm install --include=optional
if errorlevel 1 goto :error

echo.
echo Explicitly installing Sharp for Windows 32-bit...
call npm install --include=optional --os=win32 --cpu=ia32 sharp@0.34.5
if errorlevel 1 goto :error

echo.
echo Building Dot Bot Polish 002...
call npm run dist
if errorlevel 1 goto :error

echo.
echo DONE. Open the dist folder and install:
echo Dot Bot Setup 1.0.0 (32-bit Polish 002).exe
explorer "%~dp0dist"
pause
exit /b 0
:error
echo.
echo BUILD FAILED. Do not change anything. Leave this window open and show Kollin the error above.
pause
exit /b 1
