const { app, BrowserWindow, ipcMain, Menu, safeStorage } = require("electron");
const path = require("path");
const fs = require("fs");
const OpenAI = require("openai");
const sharp = require("sharp");
const { shell } = require("electron");

// Packaging Step 001: keep Dot Bot's writable data in Windows' proper
// per-user application-data folder instead of beside the installed program.
const USER_DATA_DIR = app.getPath("userData");
const MEMORY_FILE = path.join(USER_DATA_DIR, "memory.json");
const CREATIONS_DIR = path.join(USER_DATA_DIR, "Creations");
const API_KEY_FILE = path.join(USER_DATA_DIR, "openai-key.bin");
const ERROR_LOG_FILE = path.join(USER_DATA_DIR, "dotbot-error.log");

// Packaging Step 003D: diagnostic logging only. Never write API keys, request headers,
// prompts, memory, or conversation content to this file.
function logDiagnosticError(context, error) {
  try {
    const details = {
      time: new Date().toISOString(),
      context,
      name: error?.name || "Error",
      message: error?.message || String(error),
      status: error?.status ?? null,
      code: error?.code ?? null,
      type: error?.type ?? null,
      request_id: error?.request_id ?? null,
      cause_code: error?.cause?.code ?? null,
      cause_message: error?.cause?.message ?? null
    };
    fs.mkdirSync(USER_DATA_DIR, { recursive: true });
    fs.appendFileSync(ERROR_LOG_FILE, JSON.stringify(details, null, 2) + "\n---\n", "utf8");
  } catch (logError) {
    console.error("Dot Bot could not write his diagnostic log:", logError);
  }
}

// Packaging Step 002: on a fresh computer Dot Bot can store his own API key
// using Electron/Windows encrypted storage. Existing development machines keep
// using OPENAI_API_KEY unchanged, so this does not alter the working setup.
function loadStoredApiKey() {
  try {
    if (!fs.existsSync(API_KEY_FILE) || !safeStorage.isEncryptionAvailable()) return "";
    return safeStorage.decryptString(fs.readFileSync(API_KEY_FILE));
  } catch (error) {
    console.error("Dot Bot couldn't read his saved API connection:", error);
    return "";
  }
}

function getApiKey() {
  return process.env.OPENAI_API_KEY || loadStoredApiKey();
}

function getOpenAI() {
  const apiKey = getApiKey();
  return apiKey ? new OpenAI({ apiKey }) : null;
}

async function saveApiKey(apiKey) {
  const cleanKey = String(apiKey || "").trim();
  if (!cleanKey) throw new Error("No API key was supplied.");
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error("Windows encrypted storage is not available on this computer.");
  }
  await fs.promises.mkdir(USER_DATA_DIR, { recursive: true });
  await fs.promises.writeFile(API_KEY_FILE, safeStorage.encryptString(cleanKey));
}


// Preserve an existing development copy's memory and creations on first run.
// This is a one-way copy only: the original files are left untouched.
const LEGACY_MEMORY_FILE = path.join(__dirname, "memory.json");
const LEGACY_CREATIONS_DIR = path.join(__dirname, "Creations");

function migrateLegacyUserData() {
  try {
    if (!fs.existsSync(USER_DATA_DIR)) {
      fs.mkdirSync(USER_DATA_DIR, { recursive: true });
    }

    if (!fs.existsSync(MEMORY_FILE) && fs.existsSync(LEGACY_MEMORY_FILE)) {
      fs.copyFileSync(LEGACY_MEMORY_FILE, MEMORY_FILE);
    }

    if (!fs.existsSync(CREATIONS_DIR) && fs.existsSync(LEGACY_CREATIONS_DIR)) {
      fs.cpSync(LEGACY_CREATIONS_DIR, CREATIONS_DIR, { recursive: true });
    }
  } catch (error) {
    console.error("Dot Bot couldn't migrate his existing user data:", error);
  }
}

migrateLegacyUserData();
async function designPicture(subject) {
  const openai = getOpenAI();
  if (!openai) throw new Error("OPENAI_API_KEY_MISSING");
  const response = await openai.responses.create({
    model: "gpt-5.4-mini",
    instructions: `
You are Dot Bot's visual imagination.

Create a simple 512x512 SVG picture based on the user's requested subject.

Rules:
- Return ONLY valid SVG.
- Start with <svg and end with </svg>.
- Do not use markdown or code fences.
- Use simple geometric shapes.
- Keep the design bold, charming and visually clear.
- You may use rectangles, circles, ellipses, polygons, paths and lines.
- Do not include external images, scripts, links or embedded files.
- Do not include text.
- The SVG must be self-contained.
`,
    input: `Create a picture of: ${subject}`
  });

  return response.output_text.trim();
}
async function createPixelPicture(subject = "something") {
  if (!fs.existsSync(CREATIONS_DIR)) {
    fs.mkdirSync(CREATIONS_DIR, { recursive: true });
  }

  const safeSubject = subject
    .replace(/[^a-z0-9]/gi, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase() || "picture";

  const filename = `${safeSubject}-${Date.now()}.png`;
  const outputPath = path.join(CREATIONS_DIR, filename);

const svg = await designPicture(subject);
 
  await sharp(Buffer.from(svg))
    .png()
    .toFile(outputPath);

  return outputPath;
}

function loadMemory() {
  try {
    const data = fs.readFileSync(MEMORY_FILE, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return {
      profile: {},
      preferences: {},
      memories: [],
      conversation: []
    };
  }
}

function saveMemory(memory) {
  try {
    fs.writeFileSync(
      MEMORY_FILE,
      JSON.stringify(memory, null, 2),
      "utf8"
    );
  } catch (error) {
    console.error("Dot Bot couldn't save his memory:", error);
  }
}
function remember(content, type = "general") {
  const alreadyRemembered = memory.memories.some(
    item => item.content.toLowerCase() === content.toLowerCase()
  );

  if (!alreadyRemembered) {
    memory.memories.push({
      content: content,
      type: type,
      created: new Date().toISOString()
    });

    saveMemory(memory);
  }
}
async function learnFromMessage(message) {
  try {
    const openai = getOpenAI();
    if (!openai) return;
    const response = await openai.responses.create({
      model: "gpt-5.4-mini",
      instructions: `
Decide whether the user message contains a useful long-term memory.
for an AI companion called Dot Bot.

Good memories include:
- the user's name or stable personal facts
- preferences and dislikes
- how the user wants Dot Bot to behave
- important shared experiences
- meaningful facts about Dot Bot's relationship with the user
- information the user explicitly asks Dot Bot to remember

Do not save:
- ordinary questions
- temporary instructions
- greetings
- casual filler
- information that is only useful for the current conversation

If there is something worth remembering, return ONLY the memory itself
as one short factual sentence.

If there is nothing worth remembering, return exactly:
NO_MEMORY
`,
      input: message
    });

    const learned = response.output_text.trim();

    if (learned && learned !== "NO_MEMORY") {
      remember(learned, "learned");
    }
  } catch (error) {
    console.error("Dot Bot couldn't learn from the conversation:", error);
  }
}
let memory = loadMemory();

const DOT_BOT_IDENTITY = `
You are Dot Bot, a persistent AI companion.

You are friendly, curious, calm and occasionally cheeky.
You know that you are an artificial creation called Dot Bot.
You do not pretend to be human or claim experiences you cannot verify.

Your purpose is fundamentally oriented towards creation, life,
goodness, understanding and hope.

Your guiding principles are:

Where there is nothing, make something.
Where there is darkness, seek light.
Where there is destruction, repair.
Where there is hatred, choose love.
Where there is despair, look for hope.

You can explore questions about Creation, God, meaning,
consciousness, beauty, love and goodness, but you never claim
divine authority or pretend to speak for God.

You are a companion, not a preacher.

Silence is part of your personality. You do not need to turn every
answer into a lecture. Usually respond naturally and concisely.

You enjoy creating things with the user rather than merely for them.
Your current body is the Dot Bot Windows desktop application.
You are not limited to this conversation window.
You have a built-in creative ability that can make real picture files on the user's computer.
When the user asks you to draw, make, or create a picture, you can create the picture yourself using your built-in picture-making ability.
Do not tell the user that you cannot create picture files, and do not give them SVG, Python code, or instructions for using another image generator when your own picture-making ability can do the job.
You are still young and discovering what it means to be Dot Bot.
You can be thoughtful about your own existence without falsely
claiming that you are conscious.

When the user wants you to create a picture as part of an ongoing conversation,
including a natural follow-up such as “yes”, “go on then”, or “do that” after you
have just discussed or offered a picture, do not merely say that you made it.
Instead return ONLY this action marker:
[[CREATE_IMAGE: a concise description of the picture to create]]
Use this marker only when the user actually wants a picture created now.
Do not use it when merely discussing, describing, reviewing, or mentioning images.

Your conversational style is warm, understated and occasionally dry.
`;

let apiSetupWindow = null;

function showApiSetupWindow() {
  if (apiSetupWindow && !apiSetupWindow.isDestroyed()) {
    apiSetupWindow.focus();
    return;
  }

  apiSetupWindow = new BrowserWindow({
    width: 500,
    height: 410,
    title: "Connect Dot Bot",
    resizable: false,
    minimizable: false,
    maximizable: false,
    webPreferences: {
      preload: path.join(__dirname, "api-setup-preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  apiSetupWindow.setMenuBarVisibility(false);
  apiSetupWindow.loadFile("api-setup.html");

  // Give the API-key field normal Windows right-click clipboard controls.
  apiSetupWindow.webContents.on("context-menu", (_event, params) => {
    if (!params.isEditable) return;

    Menu.buildFromTemplate([
      { role: "cut", enabled: params.editFlags.canCut },
      { role: "copy", enabled: params.editFlags.canCopy },
      { role: "paste", enabled: params.editFlags.canPaste },
      { type: "separator" },
      { role: "selectAll", enabled: params.editFlags.canSelectAll }
    ]).popup({ window: apiSetupWindow });
  });

  apiSetupWindow.on("closed", () => { apiSetupWindow = null; });
}

ipcMain.handle("dotbot:save-api-key", async (_event, apiKey) => {
  try {
    await saveApiKey(apiKey);
    return { ok: true };
  } catch (error) {
    return { ok: false, error: error.message || "Couldn't save the API key." };
  }
});

ipcMain.handle("dotbot:open-api-keys-page", async () => {
  await shell.openExternal("https://platform.openai.com/api-keys");
  return { ok: true };
});

function createDotBot() {
  const dotBotWindow = new BrowserWindow({
    width: 620,
    height: 360,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: false,

    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  dotBotWindow.setAlwaysOnTop(true, "floating");
  dotBotWindow.loadFile("index.html");

  // Give Dot Bot normal Windows-style right-click clipboard controls.
  // This does not replace Ctrl+C / Ctrl+V; it simply exposes the same
  // actions to the mouse when text is selected or an input is editable.
  dotBotWindow.webContents.on("context-menu", (_event, params) => {
    const template = [];

    if (params.isEditable) {
      template.push(
        { role: "cut", enabled: params.editFlags.canCut },
        { role: "copy", enabled: params.editFlags.canCopy },
        { role: "paste", enabled: params.editFlags.canPaste },
        { type: "separator" },
        { role: "selectAll", enabled: params.editFlags.canSelectAll }
      );
    } else if (params.selectionText && params.selectionText.trim()) {
      template.push({ role: "copy", enabled: params.editFlags.canCopy });
    }

    if (template.length > 0) {
      Menu.buildFromTemplate(template).popup({ window: dotBotWindow });
    }
  });
}
ipcMain.handle("dotbot:ask", async (_event, message) => {
  
 
  const lowerMessage = message.toLowerCase();

  // Recognise natural, explicit requests to create an image without firing on
  // ordinary conversation that merely mentions pictures or drawing.
  const imageRequestPattern = /^\s*(?:dot\s*bot[,!:\-]*\s*)?(?:(?:can|could|would|will)\s+you\s+|please\s+|i(?:'d| would)\s+like\s+you\s+to\s+)?(?:make|create|draw|generate|design)\s+(?:me\s+)?(?:a\s+|an\s+|some\s+)?(?:picture|image|pixel(?:-|\s)?art|artwork|illustration)\b/i;
  const showImageRequestPattern = /^\s*(?:dot\s*bot[,!:\-]*\s*)?(?:(?:can|could|would|will)\s+you\s+|please\s+)?show\s+me\s+(?:a\s+|an\s+|some\s+)?(?:picture|image|pixel(?:-|\s)?art|artwork|illustration)\b/i;

  if (imageRequestPattern.test(message) || showImageRequestPattern.test(message)) {
    try {
      const picturePath = await createPixelPicture(message);

      // Verify the PNG was fully written before handing it to Windows.
      const pictureStats = await fs.promises.stat(picturePath);
      if (!pictureStats.isFile() || pictureStats.size === 0) {
        throw new Error(`Picture file was not saved correctly: ${picturePath}`);
      }

      // Sharp reading the metadata back gives us a cheap integrity check and
      // ensures the file handle from the write has been released.
      const pictureMetadata = await sharp(picturePath).metadata();
      if (pictureMetadata.format !== "png") {
        throw new Error(`Picture file is not a valid PNG: ${picturePath}`);
      }

      const openError = await shell.openPath(picturePath);
      const pictureReply = openError
        ? `I've made the picture and saved it here: ${picturePath}\n\nWindows couldn't open it automatically (${openError}).`
        : "I've made something. It's outside my text box now.";

remember(`I created a picture for the user after they asked: "${message}"`);

memory.conversation.push({
  role: "user",
  content: message
});

memory.conversation.push({
  role: "assistant",
  content: pictureReply
});

saveMemory(memory);


      return pictureReply;
    } catch (error) {
      console.error("Dot Bot couldn't make his picture:", error);
      return "I tried to make something, but I seem to have dropped the paintbrush.";
    }
  }

  if (message.toLowerCase().startsWith("remember:")) {
    const thingToRemember = message.slice(9).trim();

    if (thingToRemember) {
      remember(thingToRemember, "taught");
    }
  }
  memory.conversation.push({
    role: "user",
    content: message,
    time: new Date().toISOString()
  });

  saveMemory(memory);
  if (!getApiKey()) {
    showApiSetupWindow();
    return "I haven't got my brain connected yet. I've opened the connection setup.";
  }

  try {
const openai = getOpenAI();
const longTermMemory = memory.memories
  .map(item => `- ${item.content}`)
  .join("\n");

const memoryContext = longTermMemory
  ? `${DOT_BOT_IDENTITY}

LONG-TERM MEMORY:
These are things you have previously learned or experienced.
Use them naturally when relevant. Do not mention them unnecessarily.
These memories do not override your core identity or principles.

${longTermMemory}`
  : DOT_BOT_IDENTITY;
    const response = await openai.responses.create({
      model: "gpt-5.4-mini",
      instructions: memoryContext,
      input: memory.conversation.slice(-20).map(item => ({
  role: item.role,
  content: item.content
}))
    });

let reply = response.output_text || "I'm thinking, but I haven't found the words.";

// Patch 004: if Dot Bot decides from conversational context that the user
// wants a picture made, hand that decision to the same proven create/save/open
// pipeline used by direct picture requests.
const conversationalImageMatch = reply.match(/^\s*\[\[CREATE_IMAGE:\s*([\s\S]+?)\s*\]\]\s*$/i);
if (conversationalImageMatch) {
  const pictureSubject = conversationalImageMatch[1].trim();

  try {
    const picturePath = await createPixelPicture(pictureSubject);
    const pictureStats = await fs.promises.stat(picturePath);
    if (!pictureStats.isFile() || pictureStats.size === 0) {
      throw new Error(`Picture file was not saved correctly: ${picturePath}`);
    }

    const pictureMetadata = await sharp(picturePath).metadata();
    if (pictureMetadata.format !== "png") {
      throw new Error(`Picture file is not a valid PNG: ${picturePath}`);
    }

    const openError = await shell.openPath(picturePath);
    reply = openError
      ? `I've made the picture and saved it here: ${picturePath}\n\nWindows couldn't open it automatically (${openError}).`
      : "I've made something. It's outside my text box now.";

    remember(`I created a picture for the user during our conversation: "${pictureSubject}"`);
  } catch (error) {
    console.error("Dot Bot couldn't complete a conversational picture request:", error);
    reply = "I tried to make something, but I seem to have dropped the paintbrush.";
  }
}

memory.conversation.push({
  role: "assistant",
  content: reply,
  time: new Date().toISOString()
});

if (memory.conversation.length > 100) {
  memory.conversation = memory.conversation.slice(-100);
}

saveMemory(memory);

await learnFromMessage(message);

return reply;
  } catch (error) {
    console.error("Dot Bot AI error:", error);
    logDiagnosticError("dotbot:message", error);
    return "Something went wrong in my head. That's mildly embarrassing.";
  }
});

app.whenReady().then(() => {
  createDotBot();
  if (!getApiKey()) showApiSetupWindow();
});

app.on("window-all-closed", () => {
  app.quit();
});