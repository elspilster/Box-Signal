const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("dotBotSetup", {
  saveApiKey: (apiKey) => ipcRenderer.invoke("dotbot:save-api-key", apiKey),
  openApiKeysPage: () => ipcRenderer.invoke("dotbot:open-api-keys-page")
});
