const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("dotBotAI", {
  ask: (message) => ipcRenderer.invoke("dotbot:ask", message)
});